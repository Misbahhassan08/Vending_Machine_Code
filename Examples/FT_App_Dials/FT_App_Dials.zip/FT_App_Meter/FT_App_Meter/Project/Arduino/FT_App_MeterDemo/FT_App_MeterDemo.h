#ifndef _SAMPLEAPP_H_
#define _SAMPLEAPP_H_






ft_int16_t SAMAPP_qsin(ft_uint16_t a);
ft_int16_t SAMAPP_qcos(ft_uint16_t a);
ft_void_t SAMAPP_BootupConfig();


ft_void_t Abs_Meter_Dial();
ft_void_t Relative_Meter_Dial();




#endif /* _SAMPLEAPP_H_ */

/* Nothing beyond this */









